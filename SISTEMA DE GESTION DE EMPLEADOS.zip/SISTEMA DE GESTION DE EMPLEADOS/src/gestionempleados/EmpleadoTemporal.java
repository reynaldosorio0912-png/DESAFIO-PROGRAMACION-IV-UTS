package gestionempleados;

/**
 * Representa a un empleado contratado por un período determinado.
 */
public class EmpleadoTemporal extends Empleado {
    private String fechaIngreso;
    private String fechaFinContrato;
    private static final double SUELDO_BASE = 18000.0;
    private static final double BONO_POR_HIJO = 1000.0;

    public EmpleadoTemporal(String nombre, String apellido, String cedula, int cantidadHijos,
                            String fechaIngreso, String fechaFinContrato) {
        super(nombre, apellido, cedula, cantidadHijos);
        this.fechaIngreso = fechaIngreso;
        this.fechaFinContrato = fechaFinContrato;
    }

    @Override
    public double calcularSueldo() {
        return SUELDO_BASE + (getCantidadHijos() * BONO_POR_HIJO);
    }

    @Override
    public String getTipoEmpleado() {
        return "Temporal";
    }

    @Override
    public String getDetalles() {
        return "Ingreso: " + fechaIngreso + " | Fin: " + fechaFinContrato;
    }

    public String getFechaIngreso() { return fechaIngreso; }
    public void setFechaIngreso(String fechaIngreso) { this.fechaIngreso = fechaIngreso; }

    public String getFechaFinContrato() { return fechaFinContrato; }
    public void setFechaFinContrato(String fechaFinContrato) { this.fechaFinContrato = fechaFinContrato; }
}