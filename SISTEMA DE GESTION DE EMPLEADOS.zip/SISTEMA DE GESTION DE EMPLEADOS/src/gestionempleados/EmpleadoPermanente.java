package gestionempleados;

/**
 * Representa a un empleado fijo (planta permanente) con bonificación por hijos y antigüedad.
 */
public class EmpleadoPermanente extends Empleado {
    private int antiguedadAnios;
    private static final double SUELDO_BASE = 20000.0;
    private static final double BONO_POR_HIJO = 1000.0;
    private static final double BONO_POR_ANTIGUEDAD = 1000.0;

    public EmpleadoPermanente(String nombre, String apellido, String cedula, int cantidadHijos, int antiguedadAnios) {
        super(nombre, apellido, cedula, cantidadHijos);
        this.antiguedadAnios = antiguedadAnios;
    }

    @Override
    public double calcularSueldo() {
        return SUELDO_BASE + (getCantidadHijos() * BONO_POR_HIJO) + (antiguedadAnios * BONO_POR_ANTIGUEDAD);
    }

    @Override
    public String getTipoEmpleado() {
        return "Planta Permanente";
    }

    @Override
    public String getDetalles() {
        return "Antigüedad: " + antiguedadAnios + " año(s)";
    }

    public int getAntiguedadAnios() { return antiguedadAnios; }
    public void setAntiguedadAnios(int antiguedadAnios) { this.antiguedadAnios = antiguedadAnios; }
}