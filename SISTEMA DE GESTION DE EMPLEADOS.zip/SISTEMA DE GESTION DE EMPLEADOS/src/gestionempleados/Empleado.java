package gestionempleados;

/**
 * Clase base abstracta que representa a un empleado genérico de la empresa.
 * Define los atributos comunes y el método polimórfico para calcular el sueldo.
 */
public abstract class Empleado {
    private String nombre;
    private String apellido;
    private String cedula;
    private int cantidadHijos;

    /**
     * Constructor principal de la clase Empleado.
     *
     * @param nombre Nombre del empleado.
     * @param apellido Apellido del empleado.
     * @param cedula Número de identificación (cédula).
     * @param cantidadHijos Cantidad de hijos del empleado.
     */
    public Empleado(String nombre, String apellido, String cedula, int cantidadHijos) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.cantidadHijos = cantidadHijos;
    }

    /**
     * Método abstracto que será sobrescrito por cada subclase según su regla de pago.
     *
     * @return Sueldo total calculado en Bolívares (Bs.).
     */
    public abstract double calcularSueldo();

    /**
     * Devuelve el tipo de empleado para mostrar en la interfaz.
     *
     * @return Nombre descriptivo del tipo de contrato.
     */
    public abstract String getTipoEmpleado();

    /**
     * Devuelve los detalles específicos del tipo de empleado para la tabla.
     *
     * @return Cadena con los datos particulares del empleado.
     */
    public abstract String getDetalles();

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public int getCantidadHijos() { return cantidadHijos; }
    public void setCantidadHijos(int cantidadHijos) { this.cantidadHijos = cantidadHijos; }
}