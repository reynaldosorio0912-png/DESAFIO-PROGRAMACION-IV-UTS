package gestionempleados;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Interfaz gráfica de usuario (Swing) para el Sistema de Gestión de Empleados.
 */
public class SistemaEmpleadosGUI extends JFrame {


    // Almacenamiento temporal con Array tradicional
    private static final int MAX_EMPLEADOS = 100;
    private Empleado[] listaEmpleados = new Empleado[MAX_EMPLEADOS];
    private int totalEmpleados = 0;

    // Componentes del formulario
    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtCedula;
    private JTextField txtHijos;
    private JComboBox<String> cmbTipoEmpleado;

    // Campos de tipo de empleado
    private JTextField txtHoras;
    private JTextField txtFechaIngreso;
    private JTextField txtFechaFin;
    private JTextField txtAntiguedad;

    // Panel  con CardLayout para alternar campos
    private JPanel panelCamposEspecificos;
    private CardLayout cardLayout;

    // Botones
    private JButton btnGuardar;
    private JButton btnLimpiar;
    private JButton btnEliminar;

    // Tabla de registros
    private JTable tablaEmpleados;
    private DefaultTableModel modeloTabla;

    public SistemaEmpleadosGUI() {
        configurarVentana();
        inicializarComponentes();
        configurarEventos();
    }

    private void configurarVentana() {
        setTitle("Sistema de Gestión de Empleados");
        setSize(880, 580);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
    }

    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.setBorder(new EmptyBorder(12, 12, 12, 12));

        // --- PANEL SUPERIOR: FORMULARIO ---
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBorder(new TitledBorder("Registro de Empleado"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 8, 5, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Datos básicos
        gbc.gridx = 0; gbc.gridy = 0;
        panelFormulario.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        txtNombre = new JTextField(15);
        panelFormulario.add(txtNombre, gbc);

        gbc.gridx = 2;
        panelFormulario.add(new JLabel("Apellido:"), gbc);
        gbc.gridx = 3;
        txtApellido = new JTextField(15);
        panelFormulario.add(txtApellido, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panelFormulario.add(new JLabel("Cédula:"), gbc);
        gbc.gridx = 1;
        txtCedula = new JTextField(15);
        panelFormulario.add(txtCedula, gbc);

        gbc.gridx = 2;
        panelFormulario.add(new JLabel("Cantidad de Hijos:"), gbc);
        gbc.gridx = 3;
        txtHijos = new JTextField("0", 15);
        panelFormulario.add(txtHijos, gbc);

        // Selector de tipo de empleado
        gbc.gridx = 0; gbc.gridy = 2;
        panelFormulario.add(new JLabel("Tipo de Empleado:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3;
        cmbTipoEmpleado = new JComboBox<>(new String[]{
                "Empleado por Hora",
                "Empleado Temporal",
                "Empleado de Planta Permanente"
        });
        panelFormulario.add(cmbTipoEmpleado, gbc);
        gbc.gridwidth = 1;

        // Panel dinámico (CardLayout) para datos específicos
        cardLayout = new CardLayout();
        panelCamposEspecificos = new JPanel(cardLayout);
        panelCamposEspecificos.setBorder(new TitledBorder("Datos Específicos del Contrato"));

        // Tarjeta 1: Por Hora
        JPanel panelPorHora = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panelPorHora.add(new JLabel("Horas trabajadas en el mes:"));
        txtHoras = new JTextField(10);
        panelPorHora.add(txtHoras);

        // Tarjeta 2: Temporal
        JPanel panelTemporal = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panelTemporal.add(new JLabel("Fecha de Ingreso (dd/mm/aaaa):"));
        txtFechaIngreso = new JTextField(10);
        panelTemporal.add(txtFechaIngreso);
        panelTemporal.add(new JLabel("Fecha Fin Contrato (dd/mm/aaaa):"));
        txtFechaFin = new JTextField(10);
        panelTemporal.add(txtFechaFin);

        // Tarjeta 3: Permanente
        JPanel panelPermanente = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panelPermanente.add(new JLabel("Antigüedad (en años):"));
        txtAntiguedad = new JTextField(10);
        panelPermanente.add(txtAntiguedad);

        panelCamposEspecificos.add(panelPorHora, "Empleado por Hora");
        panelCamposEspecificos.add(panelTemporal, "Empleado Temporal");
        panelCamposEspecificos.add(panelPermanente, "Empleado de Planta Permanente");

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 4;
        panelFormulario.add(panelCamposEspecificos, gbc);

        // Panel de Botones del Formulario
        JPanel panelBotonesForm = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnGuardar = new JButton("Guardar");
        btnLimpiar = new JButton("Limpiar");
        panelBotonesForm.add(btnGuardar);
        panelBotonesForm.add(btnLimpiar);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 4;
        panelFormulario.add(panelBotonesForm, gbc);

        panelPrincipal.add(panelFormulario, BorderLayout.NORTH);

        // --- PANEL CENTRAL: TABLA DE EMPLEADOS ---
        String[] columnas = {"Cédula", "Nombre", "Apellido", "Hijos", "Tipo", "Detalles", "Sueldo (Bs.)"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Evita edición directa en las celdas
            }
        };

        tablaEmpleados = new JTable(modeloTabla);
        tablaEmpleados.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollTabla = new JScrollPane(tablaEmpleados);
        scrollTabla.setBorder(new TitledBorder("Empleados Registrados"));

        panelPrincipal.add(scrollTabla, BorderLayout.CENTER);

        // --- PANEL INFERIOR: ELIMINAR REGISTRO ---
        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnEliminar = new JButton("Eliminar Empleado Seleccionado");
        panelInferior.add(btnEliminar);

        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private void configurarEventos() {
        // Cambio dinámico de campos según el ComboBox
        cmbTipoEmpleado.addActionListener(e -> {
            String seleccionado = (String) cmbTipoEmpleado.getSelectedItem();
            cardLayout.show(panelCamposEspecificos, seleccionado);
        });

        // Evento Botón Guardar
        btnGuardar.addActionListener(e -> guardarEmpleado());

        // Evento Botón Limpiar
        btnLimpiar.addActionListener(e -> confirmarLimpiar());

        // Evento Botón Eliminar
        btnEliminar.addActionListener(e -> eliminarEmpleado());
    }

    /**
     * Valida los datos, solicita confirmación y almacena el empleado en el arreglo y la tabla.
     */
    private void guardarEmpleado() {
        if (totalEmpleados >= MAX_EMPLEADOS) {
            JOptionPane.showMessageDialog(this, "Se ha alcanzado el límite máximo de empleados.", "Capacidad llena", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validar campos básicos antes de preguntar
        String nombre = txtNombre.getText().trim();
        String apellido = txtApellido.getText().trim();
        String cedula = txtCedula.getText().trim();
        String hijosStr = txtHijos.getText().trim();

        if (nombre.isEmpty() || apellido.isEmpty() || cedula.isEmpty() || hijosStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los datos básicos.", "Campos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int hijos;
        try {
            hijos = Integer.parseInt(hijosStr);
            if (hijos < 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "La cantidad de hijos debe ser un número entero válido (0 o mayor).", "Error de formato", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Construir la instancia polimórfica correspondiente
        String tipo = (String) cmbTipoEmpleado.getSelectedItem();
        Empleado nuevoEmpleado = null;

        try {
            switch (tipo) {
                case "Empleado por Hora":
                    int horas = Integer.parseInt(txtHoras.getText().trim());
                    if (horas <= 0) throw new NumberFormatException();
                    nuevoEmpleado = new EmpleadoporHora(nombre, apellido, cedula, hijos, horas);
                    break;

                case "Empleado Temporal":
                    String fIngreso = txtFechaIngreso.getText().trim();
                    String fFin = txtFechaFin.getText().trim();
                    if (fIngreso.isEmpty() || fFin.isEmpty()) {
                        JOptionPane.showMessageDialog(this, "Debe ingresar ambas fechas del contrato.", "Campos incompletos", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    nuevoEmpleado = new EmpleadoTemporal(nombre, apellido, cedula, hijos, fIngreso, fFin);
                    break;

                case "Empleado de Planta Permanente":
                    int antiguedad = Integer.parseInt(txtAntiguedad.getText().trim());
                    if (antiguedad < 0) throw new NumberFormatException();
                    nuevoEmpleado = new EmpleadoPermanente(nombre, apellido, cedula, hijos, antiguedad);
                    break;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Verifique que los valores numéricos específicos (horas o antigüedad) sean válidos.", "Error de formato", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Cuadro de confirmación requerido
        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Desea guardar la información?",
                "Confirmar Guardado",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (respuesta == JOptionPane.YES_OPTION) {
            // Guardar en el arreglo
            listaEmpleados[totalEmpleados] = nuevoEmpleado;
            totalEmpleados++;

            // Actualizar tabla
            actualizarTabla();

            // Limpiar controles
            limpiarCampos();

            // Mensaje de éxito requerido
            JOptionPane.showMessageDialog(this, "Datos almacenados correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
        }
        // Si selecciona "No", no se guarda nada y se mantienen los datos en pantalla.
    }

    /**
     * Solicita confirmación antes de limpiar el formulario.
     */
    private void confirmarLimpiar() {
        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Está seguro de limpiar los datos?",
                "Confirmar Limpieza",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (respuesta == JOptionPane.YES_OPTION) {
            limpiarCampos();
        }
    }

    /**
     * Restablece todos los campos de texto y el selector a su estado inicial.
     */
    private void limpiarCampos() {
        txtNombre.setText("");
        txtApellido.setText("");
        txtCedula.setText("");
        txtHijos.setText("0");
        txtHoras.setText("");
        txtFechaIngreso.setText("");
        txtFechaFin.setText("");
        txtAntiguedad.setText("");
        cmbTipoEmpleado.setSelectedIndex(0);
        txtNombre.requestFocus();
    }

    /**
     * Elimina el empleado seleccionado en la tabla y reorganiza el arreglo.
     */
    private void eliminarEmpleado() {
        int filaSeleccionada = tablaEmpleados.getSelectedRow();

        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un empleado de la tabla para eliminar.", "Sin selección", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "¿Está seguro de eliminar al empleado seleccionado?",
                "Confirmar Eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            // Desplazar elementos en el arreglo hacia la izquierda para cubrir el hueco
            for (int i = filaSeleccionada; i < totalEmpleados - 1; i++) {
                listaEmpleados[i] = listaEmpleados[i + 1];
            }
            listaEmpleados[totalEmpleados - 1] = null;
            totalEmpleados--;

            actualizarTabla();
            JOptionPane.showMessageDialog(this, "Empleado eliminado correctamente.", "Eliminado", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Refresca el modelo de la JTable recorriendo el arreglo de empleados activos.
     */
    private void actualizarTabla() {
        modeloTabla.setRowCount(0); // Limpia filas actuales

        for (int i = 0; i < totalEmpleados; i++) {
            Empleado emp = listaEmpleados[i];
            Object[] fila = {
                    emp.getCedula(),
                    emp.getNombre(),
                    emp.getApellido(),
                    emp.getCantidadHijos(),
                    emp.getTipoEmpleado(),
                    emp.getDetalles(),
                    String.format("%,.2f Bs.", emp.calcularSueldo()) // Polimorfismo en acción
            };
            modeloTabla.addRow(fila);
        }
    }

     public static void main(String[] args) {
        // Aplicar apariencia nativa del sistema operativo
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            new SistemaEmpleadosGUI().setVisible(true);
        });
    }
}

