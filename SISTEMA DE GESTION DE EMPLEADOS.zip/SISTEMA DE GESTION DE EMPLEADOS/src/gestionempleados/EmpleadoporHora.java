package gestionempleados;

/**
 * Representa a un empleado cuyo sueldo se calcula según las horas trabajadas al mes.
 */
public class EmpleadoporHora extends Empleado {
    private int horasTrabajadas;
    private static final double TARIFA_HORA = 100.0;

    public EmpleadoporHora(String nombre, String apellido, String cedula, int cantidadHijos, int horasTrabajadas) {
        super(nombre, apellido, cedula, cantidadHijos);
        this.horasTrabajadas = horasTrabajadas;
    }

    @Override
    public double calcularSueldo() {
        return horasTrabajadas * TARIFA_HORA;
    }

    @Override
    public String getTipoEmpleado() {
        return "Por Hora";
    }

    @Override
    public String getDetalles() {
        return "Horas trabajadas: " + horasTrabajadas;
    }

    public int getHorasTrabajadas() { return horasTrabajadas; }
    public void setHorasTrabajadas(int horasTrabajadas) { this.horasTrabajadas = horasTrabajadas; }
}